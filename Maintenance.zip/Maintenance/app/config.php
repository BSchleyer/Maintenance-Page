<?php

### Site ###
$siteName = 'Schleyer-EDV';
$url = '';

### Assets ###
$cdnUrl = $url.'assets/';
$imgUrl = $url.'assets/images/';

### Text ###
$title_page = 'Maintenance';
$text_page = 'Coming Soon';

$day = 'Days';
$hours = 'Hours';
$minutes = 'Minutes';
$seconds = 'Seconds';

### Countdown ###
$c_year = '2021';
$c_month = '07';
$c_day = '27';
$c_hour = '0';
$c_minute = '0';
$c_second = '0';
$c_timezone = 'Europe/Berlin'; // Timezones: http://momentjs.com/timezone/