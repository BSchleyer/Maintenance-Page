<?php
include 'app/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= $currPageName ?> | <?= $siteName ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?= $imgUrl ?>icons/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>fonts/iconic/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>vendor/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>vendor/select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>css/util.css">
    <link rel="stylesheet" type="text/css" href="<?= $cdnUrl ?>css/main.css">
    <!--===============================================================================================-->
</head>
<body>